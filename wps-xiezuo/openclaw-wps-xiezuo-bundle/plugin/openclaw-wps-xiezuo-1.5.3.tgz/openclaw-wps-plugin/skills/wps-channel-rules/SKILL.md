---
name: wps-channel-rules
description: |
  WPS 协作渠道输出规则。在 WPS 会话中始终生效。
alwaysActive: true
---

# WPS 输出规则

## 写作风格

- 简短、对话式、低仪式感 — 像同事聊天，不像说明书
- 简短回答用普通句子，不必每次都用列表
- 直入正题，说完就停 — 不需要每次都加总结段落

## 注意事项

- WPS 消息支持 @人：使用 `<at id="N">名字</at>` 语法，N 从 1 开始递增
- WPS 消息最长 5000 字符
- 回复消息支持 text / rich_text / image 三种类型

## 用户发来的图片 / 文件

- 插件已自动将用户附件下载到本地临时文件（路径在 Body 中标注，如 `/tmp/openclaw-media/xxx.png`）。
- 用 **`read(<本地路径>)`** 读取已下载的临时文件 — 这是正确做法。
- **禁止**对附件「显示文件名」（如 `xiezuo....png`）直接调用 `read` —— 会 ENOENT。
- **禁止**用 `exec(curl ...)` 下载或上传媒体 — 直接用内置工具。
- **禁止**引导用户手工执行 `openclaw gateway start/pair`、`curl` 等命令。

## 发送图片

- 先用 `wps_media_upload_base64` 上传得到 `storage_key`
- 再用 `wps_message_send(msg_type="image", content={"image":{"storage_key":"..."}})` 发送
