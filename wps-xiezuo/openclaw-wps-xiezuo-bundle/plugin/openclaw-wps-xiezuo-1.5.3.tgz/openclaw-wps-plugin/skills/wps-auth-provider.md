---
name: wps-auth-provider
description: WPS OAuth 认证提供者
version: 1.0.0
---

# WPS Xiezuo 认证 Skill

## 功能说明

本 Skill 实现 WPS OAuth 认证流程，支持：

- OAuth 2.0 授权码模式
- Access Token 管理
- Token 自动刷新
- 用户身份验证

## 认证流程

1. **授权请求**: 引导用户到 WPS 授权页面
2. **授权回调**: 接收授权码
3. **Token 交换**: 使用授权码换取 access token
4. **Token 存储**: 安全存储 token
5. **Token 刷新**: 自动刷新过期 token

## 权限范围

- `bot.message.read`: 读取消息
- `bot.message.write`: 发送消息
- `bot.user.info`: 获取用户信息

## 配置参数

- `clientId`: WPS 应用 ID
- `clientSecret`: WPS 应用密钥
- `redirectUri`: OAuth 回调地址
- `scopes`: 权限范围列表

## 安全建议

1. 使用环境变量存储敏感信息
2. 启用 HTTPS 传输
3. 验证 state 参数防止 CSRF
4. 定期轮换密钥

## 使用示例

```typescript
// 生成授权 URL
const authUrl = authProvider.getAuthorizationUrl({
  state: 'random_state',
  scopes: ['bot.message.read', 'bot.message.write']
});

// 处理回调
const tokens = await authProvider.handleCallback({
  code: 'auth_code',
  state: 'random_state'
});

// 刷新 token
const newTokens = await authProvider.refreshToken(tokens.refreshToken);
```
