---
name: wps-calendar
description: |
  WPS 日程创建。当用户要求创建日程、添加日历事件、安排会议、设置提醒时使用。
  必须调用 wps_calendar_create，禁止生成本地文件（.ics / .txt / 脚本）。
---

# WPS 日程：创建日历事件

## 核心规则

1. **收到日程类请求时，必须且只能调用 `wps_calendar_create`。**
2. **禁止**生成 .ics 文件、提醒脚本、txt 文件、MEMORY.md 等本地替代方案。
3. 如果 tool 返回 `needsAuth: true`，告知用户"已发送授权卡片，请点击完成授权后重试"，不要做其他操作。

## 意图→工具

| 意图 | 工具 |
|------|------|
| 创建日程/会议/提醒 | `wps_calendar_create` |

## 必填参数

| 参数 | 来源 | 说明 |
|------|------|------|
| `summary` | 用户输入 | 日程标题 |
| `start_time` | 用户输入，推算为 ISO 8601 | 如"明天下午2点" → `2026-04-22T14:00:00+08:00` |
| `end_time` | 用户输入或默认 start+1h | ISO 8601 |

## 可选参数（自动从上下文获取）

| 参数 | 来源 | 说明 |
|------|------|------|
| `wps_user_id` | **直接用 SenderId** | 当前消息发送者的 ID，已在对话上下文中。**不要调用 wps_user_search 或 wps_user_get** |
| `receiver_type` | 对话类型 | 私聊填 `user`，群聊填 `chat` |
| `receiver_id` | 对话上下文 | 私聊 = SenderId，群聊 = GroupId |

## 关键约束

- **`wps_user_id` = SenderId**。直接从对话上下文的 SenderId 字段取值，不需要也不应该调用任何用户查询 API。
- 时间默认时区 `+08:00`，未指定结束时间则 +1 小时。

## 调用示例

用户在私聊中说"帮我创建明天下午2点的日程：测试授权"：

```json
{
  "summary": "测试授权",
  "start_time": "2026-04-22T14:00:00+08:00",
  "end_time": "2026-04-22T15:00:00+08:00",
  "wps_user_id": "<SenderId>",
  "receiver_type": "user",
  "receiver_id": "<SenderId>"
}
```

## 授权流程

- 首次调用时用户可能未授权，tool 返回 `needsAuth: true` 并自动发送授权卡片。
- 回复用户："已发送授权卡片，请点击「前往授权」完成授权后，再告诉我即可重试。"
- 用户授权完成后再次请求，tool 拿到 token 正常创建日程。
- **不要在授权未完成时 fallback 到任何本地方案。**

## 工具覆盖

- `wps_calendar_create` — 创建日历事件
