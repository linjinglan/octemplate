---
name: wps-message-handler
description: 处理 WPS 开放平台消息事件
version: 1.0.0
---

# WPS Xiezuo 消息处理 Skill

## 功能说明

本 Skill 负责处理来自 WPS 开放平台的消息事件，包括：

- 接收用户消息
- 解析消息内容
- 调用 AI 分析
- 回复消息到 WPS Xiezuo 聊天

## 触发条件

当收到 WPS 开放平台的 `message.receive` 事件时触发。

## 处理流程

1. 验证 Webhook 签名
2. 提取消息内容和上下文
3. 映射到 Openclaw session
4. 调用 AI 进行分析和响应
5. 通过 WPS API 发送回复

## 配置参数

- `maxRetries`: 消息发送失败重试次数（默认: 3）
- `timeout`: 消息处理超时时间（默认: 30s）
- `enableMarkdown`: 是否启用 Markdown 格式（默认: true）

## 示例

```json
{
  "event": "message.receive",
  "data": {
    "conversationId": "conv_123",
    "userId": "user_456",
    "content": "帮我分析这个文档",
    "timestamp": 1234567890
  }
}
```
