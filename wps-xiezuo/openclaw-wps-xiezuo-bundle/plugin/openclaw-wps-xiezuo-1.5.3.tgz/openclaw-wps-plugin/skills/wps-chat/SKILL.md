---
name: wps-chat
description: |
  WPS 会话与群管理。在需要创建单聊/群聊、列举会话、查会话详情、拉成员或确认应用是否在群内时使用。
---

# WPS 会话：创建、查询与成员

## 执行前必读

- **P2P**：`type` 为 `p2p`，需提供**恰好 2 个用户的 user_id**。App Token 场景下应用没有 user_id，不能作为 P2P 一方——P2P 创建通常需要用户身份授权场景。
- **群聊**：`type` 为 `group`，当前操作者自动加入并成为**群主**；`member_ids` 只需传其他成员。
- **发群消息**：使用 `wps_message_send` 的 `receiver_type=chat`，`receiver_id` 传 `chat_id`。
- **发消息前建议**：用 `wps_chat_is_member` 确认应用在群内，避免权限错误。

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 创建 P2P 或群 | `wps_chat_create` | `type`, `member_ids` |
| 分页列会话 | `wps_chat_list` | 无（可选分页） |
| 查看单个会话元数据 | `wps_chat_get` | `chat_id` |
| 列会话成员 | `wps_chat_members` | `chat_id` |
| 确认应用是否在群 | `wps_chat_is_member` | `chat_id` |

## 核心约束

- **`wps_chat_create`**
  - `type`：`p2p` 或 `group`
  - `member_ids`：用户 ID **数组**
    - P2P：提供**恰好 2 个** user_id（无自动注入，两个都需要是真实用户）
    - 群聊：传其他成员的 user_id（操作者自动加入并成为群主）
  - `name`：可选，群名（仅 group 有效）
  - 需要 `kso.chat.readwrite` 权限
- **`wps_chat_list`**
  - `page_size`：默认 50，最大 100（WPS API 要求必传，已内置兜底）
  - 支持 `page_token` 翻页
- **`wps_chat_get`**
  - 通过 `chat_id` 查会话是否存在、类型、群名等
- **`wps_chat_members`**
  - `page_size`：默认 50，最大 100（WPS API 要求必传，已内置兜底）
  - 支持 `page_token` 翻页
- **`wps_chat_is_member`**
  - 返回 `{ is_in_chat: true/false }`，用于发消息前的前置校验

## 使用场景示例

**1）创建 P2P**（提供两个用户 ID）

```json
{
  "type": "p2p",
  "member_ids": ["USER_ID_A", "USER_ID_B"]
}
```

**2）创建群聊**（操作者自动加入并为群主）

```json
{
  "type": "group",
  "member_ids": ["USER_ID_A", "USER_ID_B"],
  "name": "项目协作群"
}
```

**3）列举最近会话**

```json
{
  "page_size": 20
}
```

**4）会话详情**

```json
{
  "chat_id": "CHAT_ID"
}
```

**5）确认应用在群内**

```json
{
  "chat_id": "CHAT_ID"
}
```

## 常见错误与排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| 建群失败 | 成员 ID 无效或成员数不足 | 确认 member_ids 均为有效用户 ID |
| P2P 创建失败 | 成员数不为 2（去重后）或已存在同对会话 | 确认提供恰好 2 个不同的 user_id |
| 发群消息无反应 | 应用未入群 | 用 `wps_chat_is_member` 确认 |
| chat_id 不存在 | 会话已解散 | 用 `wps_chat_get` 检查会话状态 |

## 工具覆盖

- `wps_chat_create` — 创建会话
- `wps_chat_list` — 列举会话
- `wps_chat_get` — 查看会话详情
- `wps_chat_members` — 列举会话成员
- `wps_chat_is_member` — 判断是否在群
