---
name: wps-xiezuo-session-mapper
description: 管理 WPS Xiezuo 会话与 Openclaw session 的映射关系
version: 1.0.0
---

# WPS Xiezuo Session 映射 Skill

## 功能说明

本 Skill 负责管理 WPS Xiezuo 会话与 Openclaw session 之间的映射关系，确保：

- 同一 WPS Xiezuo 会话的消息映射到同一个 Openclaw session
- Session 隔离，避免跨会话信息泄露
- Session 生命周期管理

## 映射策略

### 策略 1: 基于会话 ID（推荐）

```
WPS conversationId -> Openclaw sessionId
```

适用场景：群聊、单聊

### 策略 2: 基于用户 ID

```
WPS userId -> Openclaw sessionId
```

适用场景：个人助手模式

## Session 生命周期

- **创建**: 首次收到消息时自动创建
- **续期**: 每次交互自动续期 TTL
- **过期**: 超过 TTL 后自动清理
- **手动清理**: 支持通过命令清理指定 session

## 配置参数

- `strategy`: 映射策略（`wps-conversation-id` | `wps-user-id`）
- `ttl`: Session 过期时间（秒，默认: 3600）
- `maxSessions`: 最大 session 数量（默认: 1000）

## 使用示例

```typescript
// 获取或创建 session
const sessionId = await sessionMapper.getOrCreate({
  conversationId: 'conv_123',
  userId: 'user_456'
});

// 续期 session
await sessionMapper.renew(sessionId);

// 清理过期 session
await sessionMapper.cleanup();
```
