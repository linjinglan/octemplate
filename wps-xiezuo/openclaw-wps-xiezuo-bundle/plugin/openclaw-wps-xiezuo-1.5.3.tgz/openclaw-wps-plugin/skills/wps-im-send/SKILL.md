---
name: wps-im-send
description: |
  WPS IM 消息发送与回复。在用户要求发消息、私聊、群聊、@某人、引用回复时使用。
---

# WPS IM：发送与回复

## 执行前必读

- **`receiver_type` 为 `user` 时**：按用户 ID 路由，走单聊（P2P），**不必先查 `chat_id`** 即可发 DM。
- **`receiver_type` 为 `chat` 时**：向群/会话发消息，`receiver_id` 传 **群 `chat_id`**。
- **回复**：仅支持 **text / rich_text / image**；需同时提供 **`chat_id`** 与被回复的 **`message_id`**。
- **content 格式**：`content` 参数是 **JSON 字符串**，结构随 `msg_type` 变化。
- **@人语法**：文本里写 `<at id="N">展示名</at>`（N 从 1 递增），并在 `mentions` 数组中提供对应的用户信息。
- **长度**：单条消息 content JSON **≤ 5000 字符**。
- **媒体**：图片等通过 **storage_key** 引用，不可把二进制内联进 JSON。

## "给 xx 发消息"路由规则（必须遵守）

当用户说"给 xx 发消息"时，"xx"可能是用户名，也可能是群聊名。**必须双查**：

### 执行步骤

1. **并行调用**两个搜索工具：
   - `wps_user_search(keyword="xx")` — 查企业用户
   - `wps_chat_find_by_name(keyword="xx")` — 查群聊/会话
2. **合并结果**，按以下规则处理：

| 用户匹配 | 群聊匹配 | 处理方式 |
|----------|----------|----------|
| 1 个 | 0 个 | 直接用 `wps_message_send(receiver_type=user)` 发 P2P |
| 0 个 | 1 个 | 直接用 `wps_message_send(receiver_type=chat)` 发群聊 |
| 1+ 个 | 1+ 个 | 展示全部候选列表（标注"用户"或"群聊"类型、群主名），让用户选择 |
| 1 个用户 | 1+ 个群 | 展示全部候选，不自动选择 |
| 1+ 个用户 | 1 个群 | 展示全部候选，不自动选择 |
| 0 个 | 0 个 | 告知用户未找到匹配，建议换关键词 |

### 禁止行为

- **禁止**只查用户不查群聊，或只查群聊不查用户
- **禁止**在两者都有匹配时自动选择一个，必须让用户确认
- **禁止**不调搜索工具就声称"找不到"
- **禁止**使用 `sessions_send` 替代 `wps_message_send`
- **禁止** P2P 发送失败后自动降级为群聊 @ 或群聊发送。必须告知用户失败原因并等待指示
- **禁止**把发消息人（用户自己）的 ID 当作 Bot ID 使用

### P2P 失败处理规则

当 `wps_message_send(receiver_type=user)` 返回 `no valid receiver` 时：
1. **立即停止重试**——不要换格式（rich_text、plain 等）重试，因为问题不在消息格式
2. **不得自动降级**——不要擅自改为群聊发送或群里 @，即使目标用户在某个群里
3. **告知用户真实原因**："`no valid receiver` 表示该用户不在应用可用范围内，或应用缺少向该用户发送 P2P 消息的权限。请在 WPS 开放平台确认该用户已加入应用可用范围，并确认应用已配置消息发送权限。"
4. **提供备选方案**：告知用户可以选择创建群聊来沟通，例如："是否要创建一个群聊，将你和目标用户拉入？"
5. **等待用户确认**——用户明确同意后才能执行 `wps_chat_create(type=group)`，Agent 不得自动创建
6. **禁止以应用身份创建 P2P**——App Token 场景下应用没有 user_id，不能作为 P2P 会话的一方，禁止尝试 `wps_chat_create(type=p2p)` 作为降级手段

## 快速索引：意图→工具

| 意图 | 工具 | 必填参数 |
|------|------|----------|
| 发新消息（常规场景，推荐） | `message` | `action=send`, `to`, `message` |
| 发新消息（精细控制 content） | `wps_message_send` | `receiver_type`, `receiver_id`, `msg_type`, `content` |
| 回复某条消息 | `wps_message_reply` | `chat_id`, `message_id`, `msg_type`, `content` |
| 按名称查找会话 | `wps_chat_find_by_name` | `keyword` |
| 按关键字查找用户 | `wps_user_search` | `keyword` |

## `message` 工具 vs `wps_message_send`

| 维度 | `message` | `wps_message_send` |
|------|-----------|-------------------|
| 来源 | Openclaw 内置通用工具 | WPS 插件注册的底层工具 |
| 参数格式 | `action=send, to="chat:<id>"` | `receiver_type, receiver_id, msg_type, content` (JSON string) |
| 推荐场景 | **常规文本发送**（简洁、首选） | 需要精细控制 content JSON 结构（富文本、@人、图片等） |

**常规发消息优先使用 `message`**；仅在需要 `mentions`、富文本、图片等高级 content 结构时使用 `wps_message_send`。

## 核心约束

- **message（推荐）**
  - `action`：`send`
  - `to`：`user:<user_id>`（私聊）或 `chat:<chat_id>`（群聊）
  - `message`：消息文本
- **发送（`wps_message_send`）**
  - `receiver_type`：`user`（私聊）或 `chat`（群聊）
  - `receiver_id`：用户 ID 或会话 ID
  - `msg_type`：`text` / `rich_text` / `image` / `file`
  - `content`：JSON 字符串，格式示例见下方
  - `mentions`：可选，@人列表数组
- **回复（`wps_message_reply`）**
  - 仅 **text / rich_text / image** 三类
  - `content` 为纯文本时自动包装为 `{ text: { content, type: "plain" } }`
  - `content` 为 JSON 时按原样使用

## 使用场景示例

**1）用户说"给研发群发消息"（推荐流程）**

```
Step 1（并行）:
  wps_user_search(keyword="研发群") → 0 结果
  wps_chat_find_by_name(keyword="研发群") → { found: true, match: { chat_id: "xxx", name: "研发群" } }

Step 2: 只有群聊匹配 → message(action=send, to="chat:xxx", message="明天下午三点开会")
```

**2）用户说"给张三发消息"（双查路由）**

```
Step 1（并行）:
  wps_user_search(keyword="张三") → 1 个用户 { user_id: "abc" }
  wps_chat_find_by_name(keyword="张三") → 1 个群 { chat_id: "def", name: "张三的项目群" }

Step 2: 两者都有 → 展示候选列表：
  "找到以下匹配，请选择发送目标：
   1. 👤 用户：张三 (user_id: abc)
   2. 💬 群聊：张三的项目群 (群主: xxx)"
```

**3）私聊用户（P2P）**

```json
{
  "receiver_type": "user",
  "receiver_id": "USER_ID",
  "msg_type": "text",
  "content": "{\"text\":{\"content\":\"你好，收到请回复。\",\"type\":\"plain\"}}"
}
```

**4）群发消息**

```json
{
  "receiver_type": "chat",
  "receiver_id": "CHAT_ID",
  "msg_type": "text",
  "content": "{\"text\":{\"content\":\"各位下午三点例会。\",\"type\":\"plain\"}}"
}
```

**5）文本中带 @**

```json
{
  "receiver_type": "chat",
  "receiver_id": "CHAT_ID",
  "msg_type": "text",
  "content": "{\"text\":{\"content\":\"<at id=\\\"1\\\">张三</at> 请确认排期。\",\"type\":\"plain\"}}",
  "mentions": [{"id": "1", "type": "user", "identity": {"id": "USER_ID_张三", "company_id": "COMPANY_ID", "type": "user"}}]
}
```

**6）回复指定消息**

```json
{
  "chat_id": "CHAT_ID",
  "message_id": "MSG_ID",
  "msg_type": "text",
  "content": "收到，我来跟进。"
}
```

## 常见错误与排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| no valid receiver | 目标用户不在应用可用范围，或应用缺少 P2P 消息权限 | 告知用户检查平台权限和可用范围，可提议创建群聊（需用户确认） |
| 403 / 无权限发群消息 | 应用未入群或未开通应用权限 | 先用 `wps_chat_is_member` 确认应用在群内 |
| @ 不生效 | 正文有 `<at>` 但 `mentions` 缺失或不匹配 | 补齐 mentions 数组，id 与正文对应 |
| 消息过长被拒 | 超过 5000 字符 | 拆成多条或压缩正文 |
| content 解析失败 | JSON 格式不正确 | 确认 content 是有效 JSON 字符串 |
| 图片发不出 | 未走 storage_key 上传链路 | 先用 `wps_media_upload` 拿 storage_key |

## 工具覆盖

- `message` — Openclaw 通用消息工具（推荐，常规文本发送）
- `wps_message_send` — 发送新消息（精细控制 content）
- `wps_message_reply` — 回复已有消息
- `wps_chat_find_by_name` — 按名称搜索会话
- `wps_user_search` — 按关键字搜索企业用户
