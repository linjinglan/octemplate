# OpenClaw WPS Xiezuo Plugin

Version: 1.5.3

## Install

```bash
openclaw plugins install ./openclaw-wps-xiezuo-1.5.3.tgz
```
