---
name: noop
description: No-op hook for plugin package compliance.
---

This hook does nothing and always returns success.
